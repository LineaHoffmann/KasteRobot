#include <iostream>
#include <unistd.h>

#include "mysql-cppconn-8/mysqlx/xdevapi.h"

using namespace mysqlx;

int main()
{
    std::cout << "Hello World!" << std::endl;

    std::string user{"riisom"};
    std::string pwd{"pwd"};
    std::string host{"localhost"};
    std::string db{"WORKSHOP"};
    uint32_t port = 33060;
    SSLMode ssl_mode = SSLMode::DISABLED;

    try {
        std::cout << "Connecting to MySQL server with:" << std::endl;
        std::cout << user << ":" << pwd << "@" << host << ":" << port << std::endl;;
        std::cout << "on database: " << db << std::endl;
        if (ssl_mode == SSLMode::DISABLED) std::cout << "SSL is disabled." << std::endl;
        Session session(
                    SessionOption::USER, user,
                    SessionOption::PWD, pwd,
                    SessionOption::HOST, host,
                    SessionOption::PORT, port,
                    SessionOption::DB, db,
                    SessionOption::SSL_MODE, ssl_mode
                    );
        std::cout << "Session accepted ..." << std::endl;
        RowResult res = session.sql("show variables like 'version'").execute();
        std::stringstream version;
        version << res.fetchOne().get(1).get<std::string>();
        int major_version;
        version >> major_version;
        if (major_version < 8) {
          std::cout << "Server is not high enough version! Must be 8 or above!" << std::endl;
          return 0;
        }
        // I assume there's already loaded the workshop database, called WORKSHOP
        Schema sch = session.getSchema("WORKSHOP");
        std::vector<std::string> sVec = sch.getTableNames();

        std::cout << "Listing found tables: " << std::endl;
        for (uint32_t i = 0; i < sVec.size(); ++i) {
            std::cout << sVec.at(i) << " | ";
        } std::cout << std::endl;

        std::cout << "Closing session ..." << std::endl;
        session.close();
    } catch (const std::exception &e) {
        std::cerr << "Something didn't go well! " << e.what() << std::endl;
    }
    return 0;
}
